﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatShelter.Models.Entities
{
    public partial class CatContext
    {

        public CatContext(DbContextOptions<CatContext> options) : base(options)
        {
            
        }


        public ListCatVM[] GetCats()
        {
            return Cat.Select(c => new ListCatVM
            {
                Name = c.Name,
                IsDangerous = c.RageRange > 5
            }).ToArray();
        }

        public void AddCat(AddCatVM catVM)
        {
            Cat.Add(new Cat
            {
                Name = catVM.Name,
                Weight = catVM.Weight,
                RageRange = catVM.RageRange
            });
            SaveChanges();
           
        }
    }
}
