﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatShelter.Models
{
    
    public class DataManager
    {
        public static List<Cat> Cats = new List<Cat>();

        public static ListCatVM[] GetCats()
        {
            return Cats.Select(c => new ListCatVM
            {
                Name = c.Name,
                IsDangerous = c.RageRange > 5
            }).ToArray();
        }

        public static void AddCat(AddCatVM addCatVM)
        {
            int id = Cats.Count + 1;

            Cats.Add(new Cat(
                id,
                addCatVM.Name,
                addCatVM.Weight,
                addCatVM.RageRange
            ));
        }
    }
}
