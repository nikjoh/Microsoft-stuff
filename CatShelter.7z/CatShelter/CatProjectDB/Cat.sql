﻿CREATE TABLE [dbo].[Cat]
(
	[Id] INT NOT NULL PRIMARY KEY identity,
	[Name] varchar(50) not null,
	[Weight] int not null,
	[RageRange] int not null
)
